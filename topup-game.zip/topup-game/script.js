// ฟังก์ชันช่วย
function saveUsers(users) { localStorage.setItem('users', JSON.stringify(users)); }
function getUsers() { return JSON.parse(localStorage.getItem('users')) || []; }

function savePackages(packages) { localStorage.setItem('packages', JSON.stringify(packages)); }
function getPackages() { return JSON.parse(localStorage.getItem('packages')) || []; }

function saveOrders(orders) { localStorage.setItem('orders', JSON.stringify(orders)); }
function getOrders() { return JSON.parse(localStorage.getItem('orders')) || []; }

function saveCurrentUser(user) { localStorage.setItem('currentUser', JSON.stringify(user)); }
function getCurrentUser() { return JSON.parse(localStorage.getItem('currentUser')); }

function saveFee(fee) { localStorage.setItem('fee', fee); }
function getFee() { return parseFloat(localStorage.getItem('fee')) || 0; }

function loadBackground() {
  const bg = localStorage.getItem('bg');
  if(bg) document.body.style.background = bg;
}

// สมัครสมาชิก
function register() {
  const nickname = document.getElementById('nickname')?.value.trim();
  const phone = document.getElementById('phoneReg')?.value.trim();
  const password = document.getElementById('passwordReg')?.value.trim();
  const msgReg = document.getElementById('msgReg');

  if (!nickname || !phone || !password) {
    if(msgReg) { msgReg.style.color = 'red'; msgReg.textContent = '⚠ กรุณากรอกข้อมูลให้ครบ'; }
    return;
  }

  let users = getUsers();
  if(users.some(u => u.phone === phone)) {
    if(msgReg) { msgReg.style.color = 'red'; msgReg.textContent = '❌ เบอร์นี้ถูกใช้งานแล้ว'; }
    return;
  }

  users.push({ nickname, phone, password, role: 'customer' });
  saveUsers(users);
  if(msgReg) {
    msgReg.style.color = 'lime';
    msgReg.textContent = 'สมัครสมาชิกสำเร็จ! กรุณาเข้าสู่ระบบ';
  }
}

// ล็อกอิน
function login() {
  const phone = document.getElementById('phone')?.value.trim();
  const password = document.getElementById('password')?.value.trim();
  const msg = document.getElementById('msg');

  if (!phone || !password) {
    if(msg) { msg.style.color = 'red'; msg.textContent = '⚠ กรุณากรอกข้อมูลให้ครบ'; }
    return;
  }

  let users = getUsers();
  let user = users.find(u => u.phone === phone && u.password === password);

  if(user) {
    saveCurrentUser(user);
    if(msg) {
      msg.style.color = 'lime';
      msg.textContent = `ยินดีต้อนรับคุณ ${user.nickname}! กำลังเข้าสู่ระบบ...`;
    }
    setTimeout(() => {
      if(user.role === 'admin') {
        window.location.href = 'admin.html';
      } else {
        window.location.href = 'shop.html';
      }
    }, 1000);
  } else {
    if(msg) {
      msg.style.color = 'red';
      msg.textContent = '❌ เบอร์หรือรหัสผ่านไม่ถูกต้อง';
    }
  }
}

// ตรวจสอบล็อกอิน
function checkLogin(redirectIfNo = true) {
  const user = getCurrentUser();
  if(!user) {
    if(redirectIfNo) {
      window.location.href = 'index.html';
    }
    return null;
  }
  return user;
}

// ออกจากระบบ
function logout() {
  localStorage.removeItem('currentUser');
  window.location.href = 'index.html';
}

// โหลดแพ็กเกจ
function renderPackages() {
  const packages = getPackages();
  const fee = getFee();
  const container = document.getElementById('packageList');
  if(!container) return;

  container.innerHTML = '';
  if(packages.length === 0) {
    container.innerHTML = '<p>ยังไม่มีแพ็กเกจให้เลือก</p>';
    return;
  }

  packages.forEach((p, i) => {
    const totalPrice = p.price + fee;
    const div = document.createElement('div');
    div.className = 'package-item';
    div.innerHTML = `
      <h3>${p.name}</h3>
      <p>ราคา: ${p.price} บาท</p>
      <p>ค่าธรรมเนียม: ${fee.toFixed(2)} บาท</p>
      <p><b>รวม: ${totalPrice.toFixed(2)} บาท</b></p>
      <button onclick="goToPayment(${i})">จ่ายเงินด้วย QR Code</button>
    `;
    container.appendChild(div);
  });
}

// ไปหน้าจ่ายเงิน
function goToPayment(index) {
  const user = checkLogin();
  if(!user) return;

  localStorage.setItem('buyPackageIndex', index);
  window.location.href = 'payment.html';
}

// แสดงประวัติการซื้อของลูกค้า
function renderOrdersCustomer() {
  const user = checkLogin();
  if(!user) return;

  const orders = getOrders().filter(o => o.userPhone === user.phone);
  const container = document.getElementById('orderList');
  if(!container) return;

  container.innerHTML = '';
  if(orders.length === 0) {
    container.innerHTML = '<p>ยังไม่มีรายการสั่งซื้อ</p>';
    return;
  }

  orders.forEach(o => {
    const div = document.createElement('div');
    div.className = 'order-item';
    div.innerHTML = `
      <p>แพ็กเกจ: ${o.packageName}</p>
      <p>ราคา: ${o.price.toFixed(2)} บาท</p>
      <p>วันที่: ${o.date}</p>
      <p>สถานะ: ${o.status || 'รอชำระเงิน'}</p>
    `;
    container.appendChild(div);
  });
}

// แสดงรายการสั่งซื้อทั้งหมด (แอดมิน)
function renderOrdersAdmin() {
  const user = checkLogin();
  if(!user || user.role !== 'admin') {
    alert('ไม่อนุญาตให้เข้าถึงหน้านี้');
    window.location.href = 'index.html';
    return;
  }

  const orders = getOrders();
  const container = document.getElementById('orderListAdmin');
  if(!container) return;

  container.innerHTML = '';
  if(orders.length === 0) {
    container.innerHTML = '<p>ยังไม่มีรายการสั่งซื้อ</p>';
    return;
  }

  let fee = getFee();
  let totalFees = 0;
  orders.forEach(o => {
    totalFees += fee;
    const div = document.createElement('div');
    div.className = 'order-admin-item';
    div.innerHTML = `
      <p>ลูกค้า: ${o.userPhone}</p>
      <p>แพ็กเกจ: ${o.packageName}</p>
      <p>ราคา: ${o.price.toFixed(2)} บาท</p>
      <p>ค่าธรรมเนียม: ${fee.toFixed(2)} บาท</p>
      <p>รวม: ${(o.price + fee).toFixed(2)} บาท</p>
      <p>วันที่: ${o.date}</p>
      <p>สถานะ: ${o.status || 'รอชำระเงิน'}</p>
    `;
    container.appendChild(div);
  });

  // แสดงค่าธรรมเนียมรวม
  const feeSummary = document.getElementById('feeSummary');
  if(feeSummary) {
    feeSummary.textContent = `ค่าธรรมเนียมรวมทั้งหมด: ${(fee * orders.length).toFixed(2)} บาท`;
  }
}

// แสดงและจัดการแพ็กเกจ (แอดมิน)
function renderPackagesAdmin() {
  const user = checkLogin();
  if(!user || user.role !== 'admin') {
    alert('ไม่อนุญาตให้เข้าถึงหน้านี้');
    window.location.href = 'index.html';
    return;
  }

  const packages = getPackages();
  const container = document.getElementById('packageAdminList');
  if(!container) return;

  container.innerHTML = '';
  packages.forEach((p, i) => {
    const div = document.createElement('div');
    div.className = 'package-admin-item';
    div.innerHTML = `
      <p><b>${p.name}</b> - ราคา: ${p.price.toFixed(2)} บาท
      <button onclick="deletePackage(${i})" style="margin-left:10px;color:red;">ลบ</button></p>
    `;
    container.appendChild(div);
  });
}

// เพิ่มแพ็กเกจ (แอดมิน)
function addPackage() {
  const name = document.getElementById('pkgName')?.value.trim();
  const priceStr = document.getElementById('pkgPrice')?.value.trim();
  if(!name || !priceStr || isNaN(priceStr)) {
    alert('กรุณากรอกชื่อและราคาที่ถูกต้อง');
    return;
  }

  const price = parseFloat(priceStr);
  let packages = getPackages();
  packages.push({ name, price });
  savePackages(packages);
  alert('